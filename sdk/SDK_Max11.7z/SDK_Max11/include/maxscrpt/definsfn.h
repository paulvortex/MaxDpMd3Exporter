// This header file is deprecated in 3ds Max 2011. 
// Please use header file listed below.
#include "..\maxscript\macros\define_instantiation_functions.h"