/*	
 *		class_ids.h - OLE Automation class id defs for MAXScript
 *
 *			Copyright � John Wainwright 1996
 *
 */
#include <Guiddef.h>

// {7FA22CB1-D26F-11d0-B260-00A0240CEEA3}
DEFINE_GUID(CLSID_MAXScript, 0x7fa22cb1, 0xd26f, 0x11d0, 0xb2, 0x60, 0x0, 0xa0, 0x24, 0xc, 0xee, 0xa3);
