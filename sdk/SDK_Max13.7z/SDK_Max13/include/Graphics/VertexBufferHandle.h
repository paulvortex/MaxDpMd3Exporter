//
// Copyright 2010 Autodesk, Inc.  All rights reserved.
//
// Use of this software is subject to the terms of the Autodesk license
// agreement provided at the time of installation or download, or which 
// otherwise accompanies this software in either electronic or hard copy form.   
//
//

#pragma once

#include "SmartHandle.h"
#include "GeometryEnums.h"

namespace MaxSDK { namespace Graphics {

/** VertexBufferHandle is a memory buffer that contain vertex data. Vertex buffers can 
contain any vertex type - transformed or untransformed, lit or unlit - that can 
be rendered through the use of the rendering methods. 
*/
class VertexBufferHandle : public SmartHandle
{
public:
	GraphicsDriverAPI VertexBufferHandle();
	GraphicsDriverAPI VertexBufferHandle(const VertexBufferHandle& from);
	GraphicsDriverAPI VertexBufferHandle& operator = (const VertexBufferHandle& from);
	GraphicsDriverAPI virtual ~VertexBufferHandle();

public:
	/** Initialize this vertex buffer. 
	\param stride The stride in bytes of each vertex of the newly created buffer. 
	\return true if successfully initialized, false otherwise.
	*/
	GraphicsDriverAPI bool Initialize(size_t stride);

	/** Clear all vertices in the buffer and set the size of the buffer to zero.
	*/
	GraphicsDriverAPI void Clear();

	/** Get the size of each vertex of this buffer. Measured in bytes.
	\return the size in bytes of each vertex.
	*/
	GraphicsDriverAPI size_t GetVertexStride() const;

	/** Get the real number of vertices in the buffer
	\return the number of vertices.
	*/
	GraphicsDriverAPI size_t GetNumberOfVertices() const;

	/** Sets the real number of vertices in the buffer.
	\param numberOfVertices the new number of vertices.
	*/
	GraphicsDriverAPI void SetNumberOfVertices(size_t numberOfVertices);

	/** Get the capacity of the buffer
	\return the capacity
	*/
	GraphicsDriverAPI size_t GetCapacity() const;

	/** Sets the reserved capacity of the buffer.
	\param new capacity of the buffer
	*/
	GraphicsDriverAPI void SetCapacity(size_t capacity);

	/** Sets the number of instance contained in the buffer.
	\param instance count
	*/
	GraphicsDriverAPI void SetInstanceCount(size_t count);

	/** Get the number of instance contained in the buffer.
	\return instance count
	*/
	GraphicsDriverAPI size_t GetInstanceCount();

	/** This function is used for reading/writing data from/into the vertex buffer.

	\remarks if the input parameter is invalid (eg. vertexIndex + numberOfVertices 
	is greater than the total number of vertices of the buffer), the function returns 
	NULL.

	\param vertexIndex the vertex index that the lock operation starts
	\param numberOfVertices the number of vertices that this function will lock.
	\return the buffer for developers to read/write vertex data. The size 
	of the buffer is numberOfVertices * vertexStride.
	*/
	GraphicsDriverAPI unsigned char* Lock(size_t vertexIndex, size_t numberOfVertices);

	/** Unlock the buffer to update. This function must be called after Lock. 
	Once this function is called, the buffer that returned by Lock become invalid 
	and should not be used any more.
	*/
	GraphicsDriverAPI void Unlock();

	/** Sets the buffer usage type.
	\param bufferType buffer usage type
	*/
	GraphicsDriverAPI void SetBufferUsageType(BufferUsageType bufferType);
};

} } // end namespace
