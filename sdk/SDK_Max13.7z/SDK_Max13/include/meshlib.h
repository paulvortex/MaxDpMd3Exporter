#pragma once

#define IMPORTING
#include "mesh.h"
#undef IMPORTING

