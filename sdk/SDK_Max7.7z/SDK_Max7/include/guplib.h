#ifndef __INGUP__
#ifndef __GUPLIB_H_
#define __GUPLIB_H_
#define GUPExport __declspec( dllimport )
#include <gup.h>
#undef  GUPExport
#endif
#endif