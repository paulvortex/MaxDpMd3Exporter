#ifndef  __INFILTERS__
#ifndef _FLTLIB_H_
#define _FLTLIB_H_
#define FLTExport __declspec( dllimport )
#include "Filters.h"
#undef  FLTExport
#endif
#endif