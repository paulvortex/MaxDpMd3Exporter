#ifndef _MESHADJLIB_H_

#define _MESHADJLIB_H_
#define IMPORTING
#include "export.h"
#include "meshadj.h"
#include "MeshDelta.h"
#undef IMPORTING

#endif

