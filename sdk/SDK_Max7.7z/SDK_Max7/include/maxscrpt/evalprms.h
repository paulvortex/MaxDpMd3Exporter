/*	
 *		eval_prims.h - evaluator primitive function defs for MAXScript
 *
 *			Copyright � John Wainwright 1996
 *
 */


	def_primitive(progn, "progn")
