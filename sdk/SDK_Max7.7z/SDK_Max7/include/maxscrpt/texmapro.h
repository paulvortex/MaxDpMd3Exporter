/*	
 *		texture_map_protocol.h - def_generics for the operations on MAX texture maps
 *
 *			Copyright � John Wainwright 1997
 *
 */
 
/* rendering */

	def_visible_generic  ( render_map,	"renderMap");
