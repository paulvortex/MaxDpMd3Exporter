	// Protocols for Physique Mod Context Vertex Interface classes
	
	def_visible_generic(ConvertToRigid,			"ConvertToRigid");
	def_visible_generic(AllowBlending,			"AllowBlending");
	def_visible_generic(GetVertexInterface,		"GetVertexInterface");
