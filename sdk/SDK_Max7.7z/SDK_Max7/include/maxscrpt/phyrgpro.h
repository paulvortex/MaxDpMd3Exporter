	// Protocols for Physique Rigid Vertex Interface classes

	def_visible_generic(GetNode,			"GetNode");
	def_visible_generic(GetOffsetVector,	"GetOffsetVector");

