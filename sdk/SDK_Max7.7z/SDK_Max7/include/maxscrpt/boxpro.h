	// Protocols for Box classes

	use_generic( eq,		"=");
	use_generic( ne,		"!=");
	use_generic( scale,		"scale");
	use_generic( translate,	"translate");

	def_visible_generic( isEmpty,	"isEmpty");			
	def_visible_generic( contains,	"contains");
	def_visible_generic( rectify,	"rectify");
	def_visible_generic( empty,		"empty");